﻿using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance { get; private set; }

    [Header("References")]
    [SerializeField] private Transform ownedListContainer;
    [SerializeField] private RewardSlot rewardSlotPrefab;
    [SerializeField] private List<EquipSlot> equipSlots; // kéo đúng 3 EquipSlot trong Inspector

    private readonly List<RewardSlot> spawnedSlots = new();

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        Refresh();
    }

    public void Refresh()
    {
        foreach (RewardSlot slot in spawnedSlots)
        {
            if (slot != null)
                Destroy(slot.gameObject);
        }
        spawnedSlots.Clear();

        foreach (RewardSO reward in PlayerReward.Instance.OwnedRewards)
        {
            RewardSlot slot = Instantiate(rewardSlotPrefab, ownedListContainer);
            slot.Setup(reward, this);
            spawnedSlots.Add(slot);
        }

        RefreshEquipSlots();
    }

    private void RefreshEquipSlots()
    {
        IReadOnlyList<RewardSO> equipped = PlayerReward.Instance.EquippedRewards;

        for (int i = 0; i < equipSlots.Count; i++)
        {
            RewardSO reward = i < equipped.Count ? equipped[i] : null;
            equipSlots[i].Setup(reward, this);
        }

        foreach (RewardSlot slot in spawnedSlots)
        {
            slot.RefreshEquippedVisual();
        }
    }

    public void OnRewardClicked(RewardSO reward)
    {
        if (PlayerReward.Instance.IsEquipped(reward))
        {
            PlayerReward.Instance.UnequipReward(reward);
        }
        else
        {
            PlayerReward.Instance.EquipReward(reward);
        }

        RefreshEquipSlots();
    }

    public void OnEquipSlotClicked(RewardSO reward)
    {
        if (reward == null)
            return;

        PlayerReward.Instance.UnequipReward(reward);
        RefreshEquipSlots();
    }

    public void OnContinuePressed()
    {
        if (BattleManager.Instance != null)
            BattleManager.Instance.ContinueFromInventory();
    }
}