﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EquipSlot : MonoBehaviour
{
    [SerializeField] private Image icon;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private Button button;
    [SerializeField] private GameObject emptyState; // hiện khi ô này chưa có reward nào

    private RewardSO reward;
    private InventoryManager owner;

    public void Setup(RewardSO reward, InventoryManager owner)
    {
        this.reward = reward;
        this.owner = owner;

        bool isEmpty = reward == null;

        if (emptyState != null)
            emptyState.SetActive(isEmpty);

        if (icon != null)
        {
            icon.enabled = !isEmpty;
            if (!isEmpty)
                icon.sprite = reward.icon;
        }

        if (nameText != null)
            nameText.text = isEmpty ? "" : reward.rewardName;

        button.onClick.RemoveAllListeners();

        if (!isEmpty)
            button.onClick.AddListener(() => owner.OnEquipSlotClicked(reward));
    }
}