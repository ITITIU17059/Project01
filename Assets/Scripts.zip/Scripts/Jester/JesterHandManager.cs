﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Quản lý 2 lá Jester (Reset / Instant Kill) - TÁCH RIÊNG hoàn toàn khỏi
// HandManager (không nằm trong handManager.handCards).
//
// Cách hoạt động: dùng CHUNG prefab bài thường (có CardDisplay, CardInteraction,
// CardPhysics, CardInputHandler) nên hover/kéo-thả y hệt bài bình thường.
// CardInteraction sẽ tự động route lựa chọn về đây (xem CardInteraction.cs,
// biến IsJesterCard) thay vì gọi HandManager.
//
// Luồng chơi: bấm/kéo lá Jester vào PlayZone ("sân") -> bấm Confirm -> thực thi
// skill -> lá bài KHÔNG bay vào discard mà bay VỀ ĐÚNG VỊ TRÍ GỐC của nó rồi
// bị khóa (mờ xám + không tương tác được) giống hệt cơ chế khóa bài của boss Q,
// cho tới khi JesterManager báo đã hồi lượt (qua rank kế tiếp).
public class JesterHandManager : MonoBehaviour
{
    public static JesterHandManager Instance { get; private set; }

    [Header("2 lá Jester - dùng chung Card Prefab, đặt sẵn trong scene,")]
    [Header("KHÔNG được là con của cardsContainer trong HandManager")]
    [SerializeField] private GameObject resetJester;        // Skill 1: xóa trait+kháng, rút lại 8 lá
    [SerializeField] private GameObject instantKillJester;  // Skill 2: giết luôn boss, không nhận thưởng

    [Header("Nút Confirm riêng cho Jester")]
    [SerializeField] private Button confirmButton;

    private CardInteraction resetInteraction;
    private CardDisplay resetDisplay;

    private CardInteraction instantKillInteraction;
    private CardDisplay instantKillDisplay;

    private GameObject selectedJester;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        if (resetJester != null)
        {
            resetInteraction = resetJester.GetComponent<CardInteraction>();
            resetDisplay = resetJester.GetComponent<CardDisplay>();

            // Ghi nhận vị trí đặt sẵn trong Editor làm "vị trí gốc" của lá này.
            // CardInteraction sẽ tự bay về đúng chỗ này mỗi khi bỏ chọn / dùng xong.
            if (resetInteraction != null)
                resetInteraction.splineLocalPosition = resetJester.transform.localPosition;
        }

        if (instantKillJester != null)
        {
            instantKillInteraction = instantKillJester.GetComponent<CardInteraction>();
            instantKillDisplay = instantKillJester.GetComponent<CardDisplay>();

            if (instantKillInteraction != null)
                instantKillInteraction.splineLocalPosition = instantKillJester.transform.localPosition;
        }

        if (confirmButton != null)
        {
            confirmButton.onClick.RemoveListener(ConfirmJester);
            confirmButton.onClick.AddListener(ConfirmJester);
        }

        Refresh();
    }

    private void OnEnable()
    {
        if (JesterManager.Instance != null)
            JesterManager.Instance.OnChanged += Refresh;

        Refresh();
    }

    private void OnDisable()
    {
        if (JesterManager.Instance != null)
            JesterManager.Instance.OnChanged -= Refresh;
    }

    //==================================================
    // ĐƯỢC GỌI TỪ CardInteraction KHI NGƯỜI CHƠI
    // BẤM / KÉO 1 LÁ JESTER VÀO SÂN (PlayZone)
    //==================================================
    public void SelectJesterCard(GameObject jester)
    {
        if (jester == null || JesterManager.Instance == null)
            return;

        // Chỉ cho chọn 1 lá Jester tại 1 thời điểm.
        if (selectedJester != null && selectedJester != jester)
        {
            SnapBack(selectedJester);
        }

        bool isReset = jester == resetJester;

        bool canUse = isReset
            ? JesterManager.Instance.CanUseReset
            : JesterManager.Instance.CanUseInstantKill;

        if (!canUse)
        {
            // Đang khóa hoặc hết lượt -> không cho chọn, bật lại vị trí gốc.
            SnapBack(jester);

            if (NotificationInfo.Instance != null)
            {
                StartCoroutine(NotificationInfo.Instance.SetUp(
                    "Jester đang bị khóa! Hãy vượt qua rank boss kế tiếp để hồi lại."));
            }

            return;
        }

        selectedJester = jester;

        if (confirmButton != null)
            confirmButton.interactable = true;
    }

    //==================================================
    // ĐƯỢC GỌI TỪ CardInteraction KHI NGƯỜI CHƠI
    // KÉO LÁ JESTER RA KHỎI SÂN (đổi ý, chưa Confirm)
    //==================================================
    public void DeselectJesterCard(GameObject jester)
    {
        if (jester != selectedJester)
            return;

        SnapBack(jester);
    }

    private void SnapBack(GameObject jester)
    {
        if (jester == null) return;

        CardInteraction interaction = jester.GetComponent<CardInteraction>();

        if (interaction != null)
            interaction.HandleDeselect(); // tự bay về đúng splineLocalPosition (vị trí gốc)

        if (jester == selectedJester)
            selectedJester = null;

        if (confirmButton != null)
            confirmButton.interactable = selectedJester != null;
    }

    //==================================================
    // CONFIRM - THỰC THI SKILL
    //==================================================
    public void ConfirmJester()
    {
        if (selectedJester == null || JesterManager.Instance == null)
            return;

        GameObject jester = selectedJester;
        bool isReset = jester == resetJester;

        if (confirmButton != null)
            confirmButton.interactable = false;

        if (isReset)
        {
            if (!JesterManager.Instance.CanUseReset)
            {
                SnapBack(jester);
                return;
            }

            BattleManager.Instance?.UseJesterReset();
        }
        else
        {
            if (!JesterManager.Instance.CanUseInstantKill)
            {
                SnapBack(jester);
                return;
            }

            BattleManager.Instance?.UseJesterInstantKill();
        }

        StartCoroutine(ReturnAfterUseRoutine(jester));
    }

    //==================================================
    // Sau khi thực hiện skill: KHÔNG discard, bay về vị trí gốc.
    // Refresh() (được gọi tự động qua JesterManager.OnChanged ngay khi
    // charge bị trừ) sẽ tự khóa (fade xám + IsLocked = true) lá vừa dùng,
    // y hệt hiệu ứng khóa bài của boss Q.
    //==================================================
    private IEnumerator ReturnAfterUseRoutine(GameObject jester)
    {
        yield return new WaitForSeconds(0.3f);

        CardInteraction interaction = jester.GetComponent<CardInteraction>();

        if (interaction != null)
            interaction.HandleDeselect();

        selectedJester = null;
    }

    //==================================================
    // REFRESH - đồng bộ trạng thái khóa/mở theo số lượt còn lại
    // trong JesterManager (CanUseReset / CanUseInstantKill).
    // Được gọi tự động mỗi khi JesterManager thay đổi (dùng, hồi, unlock, load).
    //==================================================
    public void Refresh()
    {
        if (JesterManager.Instance == null)
            return;

        bool unlocked = JesterManager.Instance.IsUnlocked;

        ApplyState(
            resetJester, resetInteraction, resetDisplay,
            unlocked, JesterManager.Instance.CanUseReset);

        ApplyState(
            instantKillJester, instantKillInteraction, instantKillDisplay,
            unlocked, JesterManager.Instance.CanUseInstantKill);

        if (confirmButton != null)
            confirmButton.interactable = selectedJester != null;
    }

    private void ApplyState(
        GameObject obj,
        CardInteraction interaction,
        CardDisplay display,
        bool unlocked,
        bool canUse)
    {
        if (obj == null)
            return;

        // Chưa từng mở khóa Jester (chưa hạ hết 4 Jack không skill) -> ẩn hẳn.
        obj.SetActive(unlocked);

        if (interaction != null)
            interaction.IsLocked = !canUse;

        if (display != null)
            display.SetFade(!canUse);
    }
}