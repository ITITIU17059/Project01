using UnityEngine;

public class TraitManager : MonoBehaviour
{
    public static TraitManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    //====================================================
    // Current Trait
    //====================================================

    public BossTraitSO CurrentTrait
    {
        get
        {
            if (BossManager.Instance == null)
                return null;

            if (BossManager.Instance.CurrentBoss == null)
                return null;

            return BossManager.Instance.CurrentBoss.currentTrait;
        }
    }

    public bool HasTrait => CurrentTrait != null;

    //====================================================
    // Event
    //====================================================

    public int ModifyDrawAmount(int amount)
    {
        return BossSkill.ModifyDrawAmount(CurrentTrait, amount);
    }

    public int ModifyHealAmount(int amount)
    {
        return BossSkill.ModifyHealAmount(CurrentTrait, amount);
    }

    public int ModifyShieldAmount(int amount)
    {
        return BossSkill.ModifyShieldAmount(CurrentTrait, amount);
    }

    public int ModifyAttackDamage(
     CardSO card,
     int originalDamage,
     int finalDamage)
    {
        return BossSkill.ModifyAttackDamage(
            CurrentTrait,
            card,
            originalDamage,
            finalDamage);
    }
    public int ModifyRewardDrawAmount(int amount)
    {
        return RewardSkill.ModifyDrawAmount(
            PlayerReward.Instance.EquippedRewards,
            amount);
    }

    public int ModifyRewardHealAmount(int amount)
    {
        return RewardSkill.ModifyHealAmount(
            PlayerReward.Instance.EquippedRewards,
            amount);
    }

    public int ModifyRewardShieldAmount(int amount)
    {
        return RewardSkill.ModifyShieldAmount(
            PlayerReward.Instance.EquippedRewards,
            amount);
    }

    public int ModifyRewardAttackDamage(
        CardSO card,
        int original,
        int finalDamage)
    {
        return RewardSkill.ModifyAttackDamage(
            PlayerReward.Instance.EquippedRewards,
            card,
            original,
            finalDamage);
    }

    public void InvokeRewardPlayerTurn()
    {
        RewardSkill.InvokePlayerTurn(
            PlayerReward.Instance.EquippedRewards);
    }

    public void InvokeRewardDiscard()
    {
        RewardSkill.InvokeDiscard(
            PlayerReward.Instance.EquippedRewards);
    }


}