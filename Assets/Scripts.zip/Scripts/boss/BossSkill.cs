using System.Collections.Generic;
using UnityEngine;

public static class BossSkill
{
    public delegate int ValueModifier(int value);

    public delegate int DamageModifier(CardSO card, int damage);

    public delegate void TraitEvent();

    private static Dictionary<TraitID, ValueModifier> drawModifiers;

    private static Dictionary<TraitID, ValueModifier> healModifiers;

    private static Dictionary<TraitID, ValueModifier> shieldModifiers;

    private static Dictionary<TraitID, DamageModifier> attackModifiers;

    private static Dictionary<TraitID, TraitEvent> playerTurnEvents;

    private static Dictionary<TraitID, TraitEvent> bossTurnEvents;

    private static Dictionary<TraitID, TraitEvent> discardEvents;

    private static Dictionary<TraitID, TraitEvent> cardPlayedEvents;
        static BossSkill()
    {
        InitializeDrawModifiers();
        InitializeHealModifiers();
        InitializeShieldModifiers();
        InitializeAttackModifiers();

        InitializePlayerTurnEvents();
        InitializeBossTurnEvents();
        InitializeDiscardEvents();
        InitializeCardPlayedEvents();
    }
    private static void InitializeDrawModifiers()
    {
        drawModifiers = new Dictionary<TraitID, ValueModifier>();
        drawModifiers.Add(
      TraitID.J_GREEDY_TRIBUTE,
      JackGreedyTribute_Draw);
    }

    private static void InitializeHealModifiers()
    {
        healModifiers = new Dictionary<TraitID, ValueModifier>();
    }

    private static void InitializeShieldModifiers()
    {
        shieldModifiers = new Dictionary<TraitID, ValueModifier>();
    }

    private static void InitializeAttackModifiers()
    {
        attackModifiers = new Dictionary<TraitID, DamageModifier>();
    }

    private static void InitializePlayerTurnEvents()
    {
        playerTurnEvents = new Dictionary<TraitID, TraitEvent>();
    }

    private static void InitializeBossTurnEvents()
    {
        bossTurnEvents = new Dictionary<TraitID, TraitEvent>();
    }

    private static void InitializeDiscardEvents()
    {
        discardEvents = new Dictionary<TraitID, TraitEvent>();
    }

    private static void InitializeCardPlayedEvents()
    {
        cardPlayedEvents = new Dictionary<TraitID, TraitEvent>();
    }
    public static int ModifyDrawAmount(BossTraitSO trait, int amount)
    {
        if (trait == null)
            return amount;

        if (drawModifiers.TryGetValue(
            trait.traitID,
            out ValueModifier modifier))
        {
            return modifier(amount);
        }

        return amount;
    }

    public static int ModifyHealAmount(BossTraitSO trait, int amount)
    {
        if (trait == null)
            return amount;

        if (healModifiers.TryGetValue(trait.traitID, out ValueModifier modifier))
            return modifier(amount);

        return amount;
    }

    public static int ModifyShieldAmount(BossTraitSO trait, int amount)
    {
        if (trait == null)
            return amount;

        if (shieldModifiers.TryGetValue(trait.traitID, out ValueModifier modifier))
            return modifier(amount);

        return amount;
    }

    public static int ModifyAttackDamage(BossTraitSO trait, CardSO card, int damage)
    {
        if (trait == null)
            return damage;

        if (attackModifiers.TryGetValue(trait.traitID, out DamageModifier modifier))
            return modifier(card, damage);

        return damage;
    }
    //==================================================
    // JACK
    //==================================================

    private static int JackGreedyTribute_Draw(int amount)
    {
        Debug.Log("Jack Greedy Tribute Activated");

        return Mathf.Min(amount, 3);
    }
}