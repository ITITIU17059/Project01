using UnityEngine;

public class ContinueButton : MonoBehaviour
{
    public void Continue()
    {
        BossManager.Instance.LoadNextBoss();
        BattleManager.Instance.ContinueFromInventory();
    }
}